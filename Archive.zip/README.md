# phoenity-icons
About this Add-on:

This is a (limited) replacement for the Phoenity Shredder theme.
Full themes are no longer supported on Thunderbird 68 and higher.

Icon size (small icons) can be set in the "Customize Toolbar" dialogs.
Supports some extensions (Cardbook, uBlockOrigin, Mail Redirect).
